﻿namespace AirlineReservationSystem
{
    internal class RandomGenerator
    {
        public RandomGenerator()
        {
        }
    }
}