﻿using System;

namespace AirlineReservationSystem
{
    internal class XmlIgnorAttribute : Attribute
    {
    }
}